const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const itemSchema = new Schema({

  emailId: {
    type: String,
    required: true,
  },
  
  calegory: {
    subCategory: {
      name:{
        type: String,
        default: null
      },
      price: {
        type: String,
        default: null
      },
      createdAt: {
        type: Date,
      },
      updatedAt: {
        type: Date,
      },
      productImages: [
        {
          url: {
            type: String,
            default: null
          },
          createdAt: {
            type: Date,
          },
        },
      ],
    }
  
  }
},

{
  timestamps: true,
}

);

module.exports = mongoose.model('items', itemSchema);

